package com.dailycodebuffer.CommonService;

//@SpringBootApplication
public class CommonServiceApplication {
	public static void main(String[] args) {
		//SpringApplication.run(CommonServiceApplication.class, args);
	}

}
