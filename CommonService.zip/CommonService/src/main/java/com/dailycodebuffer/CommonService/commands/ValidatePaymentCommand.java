package com.dailycodebuffer.CommonService.commands;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import com.dailycodebuffer.CommonService.model.CardDetail;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValidatePaymentCommand {
	
	@TargetAggregateIdentifier
	private String paymentId;
	private String orderId;
	private CardDetail cardDetail;
	

}
