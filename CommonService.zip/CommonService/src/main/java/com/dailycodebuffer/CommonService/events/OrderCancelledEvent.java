package com.dailycodebuffer.CommonService.events;

import org.axonframework.modelling.command.AggregateIdentifier;

import lombok.Data;

@Data
public class OrderCancelledEvent {
	
	@AggregateIdentifier
	private String orderId;
	private String orderStatus;


}
