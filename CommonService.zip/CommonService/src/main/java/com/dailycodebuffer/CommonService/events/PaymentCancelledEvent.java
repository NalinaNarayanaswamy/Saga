package com.dailycodebuffer.CommonService.events;

import org.axonframework.modelling.command.AggregateIdentifier;

import lombok.Data;

@Data
public class PaymentCancelledEvent {
	
	@AggregateIdentifier
	private String paymentId;
	private String orderId;
	private String paymentStatus;

}
