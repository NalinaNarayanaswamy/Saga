package com.dailycodebuffer.CommonService.events;

import lombok.NoArgsConstructor;

import lombok.AllArgsConstructor;

import lombok.Data;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentProcessedEvent {
	
	private String paymentId;
	private String orderId;

}
