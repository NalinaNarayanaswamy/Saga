package com.dailycodebuffer.CommonService;

//@SpringBootTest
class CommonServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
