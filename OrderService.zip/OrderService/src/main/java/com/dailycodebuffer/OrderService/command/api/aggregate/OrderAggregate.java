package com.dailycodebuffer.OrderService.command.api.aggregate;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;
import org.springframework.beans.BeanUtils;

import com.dailycodebuffer.CommonService.commands.CancelOrderCommand;
import com.dailycodebuffer.CommonService.commands.CompleteOrderCommand;
import com.dailycodebuffer.CommonService.events.OrderCancelledEvent;
import com.dailycodebuffer.CommonService.events.OrderCompletedEvent;
import com.dailycodebuffer.OrderService.command.api.commands.CreateOrderCommand;
import com.dailycodebuffer.OrderService.command.api.events.OrderCreatedEvent;

@Aggregate
public class OrderAggregate {
	
	
	@AggregateIdentifier
	private String orderId;
	
	private String productId;
	private String UserId;
	private String addressId;
	private Integer quantity;
	private String orderStatus;
	
	public OrderAggregate() {
	}
	
	@CommandHandler
	public OrderAggregate(CreateOrderCommand createOrderCommand) {
		//validate the command
		OrderCreatedEvent orderCreatedEvent = new OrderCreatedEvent();
		
		BeanUtils.copyProperties(createOrderCommand, orderCreatedEvent);
		
		AggregateLifecycle.apply(orderCreatedEvent); // send the details to Axon server
	
	}
	
	@EventSourcingHandler
	public void on(OrderCreatedEvent createdEvent) {
		
		this.addressId = createdEvent.getAddressId();
		this.orderId = createdEvent.getOrderId();
		this.orderStatus = createdEvent.getOrderStatus();
		this.productId = createdEvent.getProductId();
		this.quantity = createdEvent.getQuantity();
		this.UserId = createdEvent.getUserId();
		
	}
	
	@CommandHandler
	public void on(CompleteOrderCommand completeOrderCommand) {
		//validate the command , if success , publish ordercompletedevent
		
		OrderCompletedEvent completedEvent =OrderCompletedEvent.builder()
				.orderId(completeOrderCommand.getOrderId())
				.orderStatus(completeOrderCommand.getOrderStatus())
				.build(); 
		AggregateLifecycle.apply(completedEvent);
	}
	
	@EventSourcingHandler
	public void on(OrderCompletedEvent completedEvent) {
		this.orderStatus = completedEvent.getOrderStatus();
	}
	
	@CommandHandler
	public void on(CancelOrderCommand CancelOrderCommand) {
		OrderCancelledEvent cancelledEvent = new OrderCancelledEvent();
		BeanUtils.copyProperties(CancelOrderCommand, cancelledEvent);
		
		AggregateLifecycle.apply(cancelledEvent);
	}
	
	@EventSourcingHandler
	public void on (OrderCancelledEvent cancelledEvent) {
		this.orderId = cancelledEvent.getOrderId();
		this.orderStatus = cancelledEvent.getOrderStatus();
	}
}
