package com.dailycodebuffer.OrderService.command.api.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name= "ORDER", schema = "INSSET")
public class Order {
	
	@Id
	@Column(name="ORDERID")
	private String orderId;
	
	@Column(name="PRODUCTID")
	private String productId;
	
	@Column(name="USERID")
	private String UserId;
	
	@Column(name="ADDRESSID")
	private String addressId;
	
	@Column(name="QUANTITY")
	private Integer quantity;
	
	@Column(name="ORDERSTATUS")
	private String orderStatus;

}
