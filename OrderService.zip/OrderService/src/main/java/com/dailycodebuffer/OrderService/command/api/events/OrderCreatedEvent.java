package com.dailycodebuffer.OrderService.command.api.events;

import org.axonframework.modelling.command.AggregateIdentifier;

import lombok.Data;

@Data
public class OrderCreatedEvent {
	
	private String orderId;
	private String productId;
	private String UserId;
	private String addressId;
	private Integer quantity;
	private String orderStatus;
	
	

}
