package com.dailycodebuffer.OrderService.command.api.events;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.dailycodebuffer.CommonService.events.OrderCancelledEvent;
import com.dailycodebuffer.CommonService.events.OrderCompletedEvent;
import com.dailycodebuffer.OrderService.command.api.data.Order;
import com.dailycodebuffer.OrderService.command.api.data.OrderRepository;

@Component
public class OrderEventsHandler {
	
	private OrderRepository orderRepository;
	
	
	public OrderEventsHandler(OrderRepository orderRepository) {
		this.orderRepository = orderRepository;
	}


	@EventHandler
	public void on (OrderCreatedEvent createdEvent) {
		
		Order order = new Order();
		BeanUtils.copyProperties(createdEvent, order);
		orderRepository.save(order);
		
	}
	
	@EventHandler
	public void on(OrderCompletedEvent orderCompletedEvent) {
		
		Order order = orderRepository.findById(orderCompletedEvent.getOrderId()).get();
		order.setOrderStatus(orderCompletedEvent.getOrderStatus());
		orderRepository.save(order);
	}
	
	@EventHandler
	public void on(OrderCancelledEvent cancelledEvent) {
		Order order = orderRepository.findById(cancelledEvent.getOrderId()).get();
		order.setOrderStatus(cancelledEvent.getOrderStatus());
		orderRepository.save(order);
	}

}
