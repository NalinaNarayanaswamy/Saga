package com.dailycodebuffer.OrderService.command.api.model;

import lombok.NoArgsConstructor;

import lombok.AllArgsConstructor;

import lombok.Data;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderRestModel {
	
	private String productId;
	private String UserId;
	private String addressId;
	private Integer quantity;

}
