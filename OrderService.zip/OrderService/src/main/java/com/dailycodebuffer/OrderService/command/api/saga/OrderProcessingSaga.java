package com.dailycodebuffer.OrderService.command.api.saga;

import java.util.UUID;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.modelling.saga.EndSaga;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.queryhandling.QueryGateway;
import org.axonframework.spring.stereotype.Saga;
import org.springframework.beans.factory.annotation.Autowired;

import com.dailycodebuffer.CommonService.commands.CancelOrderCommand;
import com.dailycodebuffer.CommonService.commands.CancelPaymentCommand;
import com.dailycodebuffer.CommonService.commands.CompleteOrderCommand;
import com.dailycodebuffer.CommonService.commands.ShipOrderCommand;
import com.dailycodebuffer.CommonService.commands.ValidatePaymentCommand;
import com.dailycodebuffer.CommonService.events.OrderCancelledEvent;
import com.dailycodebuffer.CommonService.events.OrderCompletedEvent;
import com.dailycodebuffer.CommonService.events.OrderShippedEvent;
import com.dailycodebuffer.CommonService.events.PaymentCancelledEvent;
import com.dailycodebuffer.CommonService.events.PaymentProcessedEvent;
import com.dailycodebuffer.CommonService.model.User;
import com.dailycodebuffer.CommonService.queries.GetUserPaymentDetailsQuery;
import com.dailycodebuffer.OrderService.command.api.events.OrderCreatedEvent;

import lombok.extern.slf4j.Slf4j;

@Saga
@Slf4j
public class OrderProcessingSaga {
	
	//every event will start saga or end saga
	
	//make u start the saga and end the saga
	
	@Autowired
	private QueryGateway queryGateway;
	
	@Autowired
	private CommandGateway commandGateway;
	
	//constructor injection is not working for Saga , have corrected it in later version
	/*public OrderProcessingSaga(QueryGateway queryGateway, CommandGateway commandGateway) {
		this.queryGateway = queryGateway;
		this.commandGateway = commandGateway;
	}*/


	
	@StartSaga
	@SagaEventHandler(associationProperty = "orderId")
	private void handle(OrderCreatedEvent orderCreatedEvent)
	{
		log.info("Start Saga Ordercreated event for order id: {} ", orderCreatedEvent.getOrderId());
		
		GetUserPaymentDetailsQuery getUserPaymentDetailsQuery =
				new GetUserPaymentDetailsQuery(orderCreatedEvent.getOrderId());
		
		User user= null;
		try {
			user = queryGateway.query(getUserPaymentDetailsQuery, ResponseTypes.instanceOf(User.class)).join();
		} catch (Exception e) {
			log.error(e.getMessage());
			//start the compensating transaction
			
			cancelOrderCommand(orderCreatedEvent.getOrderId());
		}
		ValidatePaymentCommand validatePaymentCommand = ValidatePaymentCommand.builder()
				.cardDetail(user.getCardDetail())
				.orderId(orderCreatedEvent.getUserId())
				.paymentId(UUID.randomUUID().toString())
				.build();
		
		commandGateway.sendAndWait(validatePaymentCommand);
		
	}
	
	@CommandHandler
	private void cancelOrderCommand(String orderId) {
		CancelOrderCommand cancelOrderCommand = new CancelOrderCommand(orderId);
		commandGateway.sendAndWait(cancelOrderCommand);
		
		
	}

	@SagaEventHandler(associationProperty = "orderId")
	private void handle(PaymentProcessedEvent event) {
		try {
			ShipOrderCommand shipOrderCommand = ShipOrderCommand.builder()
					.shipmentId(UUID.randomUUID().toString())
					.orderId(event.getOrderId())
					.build();
			commandGateway.sendAndWait(shipOrderCommand);
		} catch (Exception e) {
			log.error(e.getMessage());
			//start the compensating transaction
			cancelPaymentCommand(event);
		}
	}
	
	//@CommandHandler
	private void cancelPaymentCommand(PaymentProcessedEvent event) {
		CancelPaymentCommand CancelPaymentCommand = new CancelPaymentCommand(event.getPaymentId(), event.getOrderId());
		commandGateway.send(CancelPaymentCommand);
	}
	
	//public void on()

	@SagaEventHandler(associationProperty = "orderId")
	private void handle(OrderShippedEvent event) {
		log.info("Start Saga OrderShippedEvent event for order id: {} ", event.getOrderId());
		CompleteOrderCommand compleOrderCommand = CompleteOrderCommand.builder()
				.orderId(event.getOrderId())
				.orderStatus("APPROVED")
				.build();
		commandGateway.sendAndWait(compleOrderCommand);
		
	}
	
	@SagaEventHandler(associationProperty = "orderId")
	@EndSaga
	public void on(OrderCompletedEvent orderCompletedEvent) {
		log.info("Start Saga orderCompletedEvent event for order id: {} ", orderCompletedEvent.getOrderId());
	}
	
	@SagaEventHandler(associationProperty = "userId")
	@EndSaga
	public void handle(OrderCancelledEvent cancelledEvent) {
		log.info("Start Saga OrderCancelledEvent event for order id: {} ", cancelledEvent.getOrderId());
	}
	
	@SagaEventHandler(associationProperty = "orderId")
	public void handle(PaymentCancelledEvent cancelledEvent) {
		log.info("Start Saga PaymentCancelledEvent event for order id: {} ", cancelledEvent.getOrderId());
		
		cancelOrderCommand(cancelledEvent.getOrderId());
	}

}
