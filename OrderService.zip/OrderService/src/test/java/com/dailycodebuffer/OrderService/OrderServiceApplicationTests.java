package com.dailycodebuffer.OrderService;

//@SpringBootTest
class OrderServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
