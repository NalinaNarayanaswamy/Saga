package com.dailycodebuffer.PaymentService.command.aggregate;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;
import org.springframework.beans.BeanUtils;

import com.dailycodebuffer.CommonService.commands.CancelPaymentCommand;
import com.dailycodebuffer.CommonService.commands.ValidatePaymentCommand;
import com.dailycodebuffer.CommonService.events.PaymentCancelledEvent;
import com.dailycodebuffer.CommonService.events.PaymentProcessedEvent;

import lombok.extern.slf4j.Slf4j;

@Aggregate
@Slf4j
public class PaymentAggregate {
	
	@AggregateIdentifier
	private String paymentId;
	private String orderId;
	private String paymentStatus;
	
	public PaymentAggregate() {
	}
	
	@CommandHandler
	public PaymentAggregate(ValidatePaymentCommand validatePaymentCommand) {
		//Validate the payment details . if success, publish payment processed event
		
		log.info("Executing validate command for order id: {} and payment id: {} ",
				validatePaymentCommand.getOrderId(), validatePaymentCommand.getPaymentId());
		
		PaymentProcessedEvent paymentProcessedEvent = new PaymentProcessedEvent(validatePaymentCommand.getOrderId(), validatePaymentCommand.getPaymentId());
		
		AggregateLifecycle.apply(paymentProcessedEvent);
		
	}
	
	@EventSourcingHandler
	public void on(PaymentProcessedEvent paymentProcessedEvent) {
		this.paymentId = paymentProcessedEvent.getPaymentId();
		this.orderId = paymentProcessedEvent.getOrderId();
	}
	
	@CommandHandler
	public void handle(CancelPaymentCommand CancelPaymentCommand) {
		PaymentCancelledEvent cancelledEvent = new PaymentCancelledEvent();
		BeanUtils.copyProperties(CancelPaymentCommand, cancelledEvent);
		AggregateLifecycle.apply(cancelledEvent);
	}
	
	@EventSourcingHandler
	public void on(PaymentCancelledEvent paymentCancelledEvent) {
		
		this.paymentStatus = paymentCancelledEvent.getPaymentStatus();
		
	}

}
