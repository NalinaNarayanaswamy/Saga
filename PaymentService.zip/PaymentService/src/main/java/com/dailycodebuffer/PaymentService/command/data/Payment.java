package com.dailycodebuffer.PaymentService.command.data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "PAYMENT", schema = "INSSET")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Payment {
	
	@Id
	@Column(name= "PAYMENTID")
	private String paymentId;
	
	@Column(name= "ORDERID")
	private String orderId;
	
	@Column(name= "TIMESTAMP")
	private Date timestamp;
	
	@Column(name= "PAYMENTSTATUS")
	private String paymentStatus;

}
