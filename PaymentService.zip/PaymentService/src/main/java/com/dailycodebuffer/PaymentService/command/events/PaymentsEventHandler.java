package com.dailycodebuffer.PaymentService.command.events;

import java.util.Date;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import com.dailycodebuffer.CommonService.events.PaymentCancelledEvent;
import com.dailycodebuffer.CommonService.events.PaymentProcessedEvent;
import com.dailycodebuffer.PaymentService.command.data.Payment;
import com.dailycodebuffer.PaymentService.command.data.PaymentRepository;

@Component
public class PaymentsEventHandler {
	
	private PaymentRepository paymentRepository;
	
	
	public PaymentsEventHandler(PaymentRepository paymentRepository) {
		this.paymentRepository = paymentRepository;
	}


	@EventHandler
	public void on(PaymentProcessedEvent event) {
		Payment payment = Payment.builder()
				.orderId(event.getOrderId())
				.paymentId(event.getPaymentId())
				.paymentStatus("COMPLETED")
				.timestamp(new Date())
				.build();
		
		paymentRepository.save(payment);
	}
	
	@EventHandler
	public void on(PaymentCancelledEvent paymentCancelledEvent) {
		Payment payment = paymentRepository.findById(paymentCancelledEvent.getPaymentId()).get();
		payment.setPaymentStatus(paymentCancelledEvent.getPaymentStatus());
		paymentRepository.save(payment);
	}

}
