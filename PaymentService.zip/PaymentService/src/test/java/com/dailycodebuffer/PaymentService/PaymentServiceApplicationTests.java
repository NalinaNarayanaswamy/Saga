package com.dailycodebuffer.PaymentService;

//@SpringBootTest
class PaymentServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
