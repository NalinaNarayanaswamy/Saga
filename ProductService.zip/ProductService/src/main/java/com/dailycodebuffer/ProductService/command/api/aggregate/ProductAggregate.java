package com.dailycodebuffer.ProductService.command.api.aggregate;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;
import org.springframework.beans.BeanUtils;

import com.dailycodebuffer.ProductService.command.api.commands.CreateProductCommand;
import com.dailycodebuffer.ProductService.command.api.events.ProductCreatedEvent;

@Aggregate
public class ProductAggregate {
	
	
	@AggregateIdentifier
	private String productId;
	private String name;
	private Integer price;
	private Integer quantity;
	
	public ProductAggregate() {
		
	}
	
	@CommandHandler
	public ProductAggregate(CreateProductCommand createProductCommand) {
		
		//We can perform different validations here, once done, create an event
		
		/*ProductCreatedEvent productCreatedEvent = ProductCreatedEvent.builder()
				.name(createProductCommand.getName())
				.price(createProductCommand.getPrice())
				.quantity(createProductCommand.getQuantity())
				.build();*/
		ProductCreatedEvent productCreatedEvent = new ProductCreatedEvent();
		BeanUtils.copyProperties(createProductCommand, productCreatedEvent);
		AggregateLifecycle.apply(productCreatedEvent);
		
	}
	
	@EventSourcingHandler // to handle the state of that command
	public void on(ProductCreatedEvent createdEvent) {
		
		this.quantity = createdEvent.getQuantity();
		this.name = createdEvent.getName();
		this.price = createdEvent.getPrice();
		this.productId= createdEvent.getProductId();
		
	}
	
	

}
