package com.dailycodebuffer.ProductService.command.api.commands;

import java.math.BigDecimal;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateProductCommand {
	
	//Command and aggregatot will compare this id 
	@TargetAggregateIdentifier
	private String productId;
	private String name;
	private Integer price;
	private Integer quantity;

}
