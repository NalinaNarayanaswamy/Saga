package com.dailycodebuffer.ProductService.command.api.controller;

import java.util.UUID;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dailycodebuffer.ProductService.command.api.commands.CreateProductCommand;
import com.dailycodebuffer.ProductService.command.api.model.ProductRestModel;

@RestController
@RequestMapping("/products")
public class ProductCommandController {
	
	 
	
	public ProductCommandController(CommandGateway commandGateway) {
		this.commandGateway = commandGateway;
	}

	private CommandGateway commandGateway;
	
	@PostMapping
	public String addProduct(@RequestBody ProductRestModel model) {
		
		CreateProductCommand createProductCommand = 
				CreateProductCommand.builder()
				.productId(UUID.randomUUID().toString())
				.name(model.getName())
				.quantity(model.getQuantity())
				.price(model.getPrice())
				.build();
		String result = commandGateway.sendAndWait(createProductCommand);
		return result;
		
	}

}
