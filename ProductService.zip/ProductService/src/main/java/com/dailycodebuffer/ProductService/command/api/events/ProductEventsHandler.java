package com.dailycodebuffer.ProductService.command.api.events;

import org.axonframework.config.ProcessingGroup;
import org.axonframework.eventhandling.EventHandler;
import org.axonframework.messaging.interceptors.ExceptionHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.dailycodebuffer.ProductService.command.api.entity.Product;
import com.dailycodebuffer.ProductService.command.api.repository.ProductRepository;

@Component
@ProcessingGroup("product")
public class ProductEventsHandler {
	
	private ProductRepository procudtRepository;
	
	public ProductEventsHandler(ProductRepository procudtRepository) {
		this.procudtRepository = procudtRepository;
		
	}
	

	@EventHandler
	public void on(ProductCreatedEvent createdEvent) throws Exception { // can give nay method name
		Product entity = new Product();
		BeanUtils.copyProperties(createdEvent, entity);
		procudtRepository.save(entity);
		
		throw new Exception("An Exception occurred");
		
	}
	
	@ExceptionHandler
	public void handle(Exception e) throws Exception {
		throw e;
	}
}
