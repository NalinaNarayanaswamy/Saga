package com.dailycodebuffer.ProductService.query.api.controller;

import java.util.List;

import org.axonframework.messaging.responsetypes.ResponseType;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.queryhandling.QueryGateway;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dailycodebuffer.ProductService.command.api.model.ProductRestModel;
import com.dailycodebuffer.ProductService.query.api.queries.GetProductQuery;

@RestController
@RequestMapping("/products")
public class QueryController {
	
	private QueryGateway queryGateway;
	
	public QueryController(QueryGateway queryGateway) {
		this.queryGateway = queryGateway;
	}



	@GetMapping
	public List<ProductRestModel> getAllProducts(){
		
		GetProductQuery productQuery = new GetProductQuery();
		
		List<ProductRestModel> productRestModels = queryGateway.query(productQuery, 
				ResponseTypes.multipleInstancesOf(ProductRestModel.class))
				.join();
		return productRestModels;
	}
}
