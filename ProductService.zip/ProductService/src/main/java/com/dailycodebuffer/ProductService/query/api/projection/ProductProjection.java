package com.dailycodebuffer.ProductService.query.api.projection;

import java.util.List;
import java.util.stream.Collectors;

import org.axonframework.queryhandling.QueryHandler;
import org.springframework.stereotype.Component;

import com.dailycodebuffer.ProductService.command.api.entity.Product;
import com.dailycodebuffer.ProductService.command.api.model.ProductRestModel;
import com.dailycodebuffer.ProductService.command.api.repository.ProductRepository;
import com.dailycodebuffer.ProductService.query.api.queries.GetProductQuery;

@Component
public class ProductProjection {

	private ProductRepository productRepository;

	public ProductProjection(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@QueryHandler
	public List<ProductRestModel> handle(GetProductQuery getProductQuery) {
		List<Product> products= productRepository.findAll();
		
		List<ProductRestModel> productRestModels = products
				.stream().map(product-> ProductRestModel.builder()
						.name(product.getName())
						.price(product.getPrice())
						.quantity(product.getQuantity())
						.build())
				.collect(Collectors.toList());
		
		return productRestModels;
	}
}
