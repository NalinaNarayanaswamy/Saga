package com.dailycodebuffer.ProductService.query.api.queries;



public class GetProductQuery {

}
