package com.dailycodebuffer.ProductService;

//@SpringBootTest
class ProductServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
