package com.dailycodebuffer.ShipmentService.command.api.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "SHIPMENT", schema = "INSSET")
@AllArgsConstructor
@NoArgsConstructor
public class Shipment {
	
	@Id
	@Column(name= "SHIPMENTID")
	private String shipmentId;
	
	@Column(name= "ORDERID")
	private String orderId;
	
	@Column(name= "SHIPMENTSTATUS")
	private String shipmeneStatus;

}
