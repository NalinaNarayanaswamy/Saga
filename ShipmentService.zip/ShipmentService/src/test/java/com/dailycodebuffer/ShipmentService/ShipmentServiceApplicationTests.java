package com.dailycodebuffer.ShipmentService;

//@SpringBootTest
class ShipmentServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
