package com.dailycodebuffer.UserService.query.api.projection;

import org.axonframework.queryhandling.QueryHandler;
import org.springframework.stereotype.Component;

import com.dailycodebuffer.CommonService.model.CardDetail;
import com.dailycodebuffer.CommonService.model.User;
import com.dailycodebuffer.CommonService.queries.GetUserPaymentDetailsQuery;

@Component
public class UserProjection {
	
	@QueryHandler
	public User getUserPaymentDetails(GetUserPaymentDetailsQuery getUserPaymentDetailsQuery) {
		
		//Ideally get the details from the dB
		CardDetail cardDetail = CardDetail.builder().
				name("Nalina")
				.cardNumber("12345")
				.cvv(111)
				.validUntilMonth(12)
				.validUntilYear(2023)
				.build();
		return  User.builder()
				.userId(getUserPaymentDetailsQuery.getUserId())
				.firstName("Nalina")
				.lastName("Narayanswamy")
				.cardDetail(cardDetail)
				.build();
		
		
	}

}
