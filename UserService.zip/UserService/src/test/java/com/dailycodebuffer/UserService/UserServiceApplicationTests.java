package com.dailycodebuffer.UserService;

//@SpringBootTest
class UserServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
