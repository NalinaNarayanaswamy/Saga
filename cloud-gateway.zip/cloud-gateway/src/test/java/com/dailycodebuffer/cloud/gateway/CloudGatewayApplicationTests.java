package com.dailycodebuffer.cloud.gateway;

//@SpringBootTest
class CloudGatewayApplicationTests {

	//@Test
	void contextLoads() {
	}

}
