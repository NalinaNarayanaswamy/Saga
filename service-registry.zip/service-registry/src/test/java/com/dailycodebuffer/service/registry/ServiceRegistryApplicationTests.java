package com.dailycodebuffer.service.registry;

//@SpringBootTest
class ServiceRegistryApplicationTests {

	//@Test
	void contextLoads() {
	}

}
