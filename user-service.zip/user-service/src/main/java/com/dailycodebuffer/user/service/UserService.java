package com.dailycodebuffer.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dailycodebuffer.user.entity.User;
import com.dailycodebuffer.user.repository.UserRepository;
import com.dailycodebuffer.user.valueobjects.Department;
import com.dailycodebuffer.user.valueobjects.ResponseTemplateVO;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

	@Autowired
	private UserRepository repository;

	@Autowired
	private RestTemplate restTemplate;

	public User saveUser(User user) {
		log.info("Entered UserService saveUser " );
		return repository.save(user);
		 
	}

	public ResponseTemplateVO getUserWithDepartment(Long userId) {
		ResponseTemplateVO responseTemplateVO = new ResponseTemplateVO();
		User user = repository.findByUserId(userId);

		Department department = restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/" + user.getDepartmentId(),
				Department.class);

		responseTemplateVO.setUser(user);
		responseTemplateVO.setDepartment(department);
		return responseTemplateVO;
	}
	
	public static final String USERSERVICE = "userService";
	
	int count=0;
	
	//@CircuitBreaker(name = USERSERVICE, fallbackMethod = "getUserFallBackMethod")
	@Retry(name=USERSERVICE, fallbackMethod = "getUserFallBackMethod")
	public ResponseTemplateVO getUserWithDepartmentUsingResilience4J(Long userId) {
		ResponseTemplateVO responseTemplateVO = new ResponseTemplateVO();
		User user = repository.findByUserId(userId);
		System.out.println("Retry called "+count++ +" times");
		Department department = restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/" + user.getDepartmentId(),
				Department.class);
		

		responseTemplateVO.setUser(user);
		responseTemplateVO.setDepartment(department);
		return responseTemplateVO;
	}
	
	public ResponseTemplateVO getUserFallBackMethod(Exception e) {
		
		ResponseTemplateVO responseTemplateVO = new ResponseTemplateVO();
		
		User user  = new User();
		user.setFirstName("fallbackFirstName");
		user.setLastName("fallbackLastName");
		user.setUserId(1l);
		user.setDepartmentId(1l);
		
		Department department = new Department();
		responseTemplateVO.setUser(user);
		responseTemplateVO.setDepartment(department);
		return responseTemplateVO;
	}

}
