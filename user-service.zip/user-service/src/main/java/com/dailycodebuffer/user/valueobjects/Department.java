package com.dailycodebuffer.user.valueobjects;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Department {
	
	@Column(name="DEPARTMENTID")
	Long departmentId;
	
	@Column(name = "DEPARTMENTNAME")
	String departmentName;
	
	@Column(name = "DEPARTMENTADDRESS")
	String departmentAddress;
	
	@Column(name = "DEPARTMENTCODE")
	String departmentCode;

}
