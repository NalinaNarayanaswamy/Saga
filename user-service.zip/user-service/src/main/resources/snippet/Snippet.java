package snippet;

public class Snippet {
	 Could not locate PropertySource and the resource is not optional, failing
}

