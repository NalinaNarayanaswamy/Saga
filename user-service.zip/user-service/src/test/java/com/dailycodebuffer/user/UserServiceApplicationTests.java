package com.dailycodebuffer.user;

//@SpringBootTest
class UserServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
